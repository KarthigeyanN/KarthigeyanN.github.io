<?php
/**
 * Karthi Portfolio Theme Functions
 *
 * @package Karthi_Portfolio
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme setup
 */
function karthi_portfolio_setup() {
    // Add theme support for various features
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 100,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('customize-selective-refresh-widgets');

    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'karthi-portfolio'),
        'footer'  => __('Footer Menu', 'karthi-portfolio'),
    ));

    // Add excerpt support for pages
    add_post_type_support('page', 'excerpt');
}
add_action('after_setup_theme', 'karthi_portfolio_setup');

/**
 * Enqueue scripts and styles
 */
function karthi_portfolio_scripts() {
    // Enqueue Google Fonts
    wp_enqueue_style('karthi-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap', array(), null);

    // Enqueue main stylesheet
    wp_enqueue_style('karthi-style', get_stylesheet_uri(), array(), '1.0.0');

    // Enqueue theme toggle script
    wp_enqueue_script('karthi-theme', get_template_directory_uri() . '/js/theme.js', array(), '1.0.0', true);

    // Enqueue particles script
    wp_enqueue_script('karthi-particles', get_template_directory_uri() . '/js/particles.js', array(), '1.0.0', true);

    // Localize script for theme data
    wp_localize_script('karthi-theme', 'karthiTheme', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('karthi_theme_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'karthi_portfolio_scripts');

/**
 * Register widget areas
 */
function karthi_portfolio_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widget Area', 'karthi-portfolio'),
        'id'            => 'footer-widgets',
        'description'   => __('Add widgets here to appear in your footer.', 'karthi-portfolio'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'karthi_portfolio_widgets_init');

/**
 * Register Custom Post Type for Projects
 */
function karthi_portfolio_register_projects_cpt() {
    $labels = array(
        'name'                  => _x('Projects', 'Post Type General Name', 'karthi-portfolio'),
        'singular_name'         => _x('Project', 'Post Type Singular Name', 'karthi-portfolio'),
        'menu_name'             => __('Projects', 'karthi-portfolio'),
        'name_admin_bar'        => __('Project', 'karthi-portfolio'),
        'archives'              => __('Project Archives', 'karthi-portfolio'),
        'attributes'            => __('Project Attributes', 'karthi-portfolio'),
        'parent_item_colon'     => __('Parent Project:', 'karthi-portfolio'),
        'all_items'             => __('All Projects', 'karthi-portfolio'),
        'add_new_item'          => __('Add New Project', 'karthi-portfolio'),
        'add_new'               => __('Add New', 'karthi-portfolio'),
        'new_item'              => __('New Project', 'karthi-portfolio'),
        'edit_item'             => __('Edit Project', 'karthi-portfolio'),
        'update_item'           => __('Update Project', 'karthi-portfolio'),
        'view_item'             => __('View Project', 'karthi-portfolio'),
        'view_items'            => __('View Projects', 'karthi-portfolio'),
        'search_items'          => __('Search Project', 'karthi-portfolio'),
        'not_found'             => __('Not found', 'karthi-portfolio'),
        'not_found_in_trash'    => __('Not found in Trash', 'karthi-portfolio'),
        'featured_image'        => __('Featured Image', 'karthi-portfolio'),
        'set_featured_image'    => __('Set featured image', 'karthi-portfolio'),
        'remove_featured_image' => __('Remove featured image', 'karthi-portfolio'),
        'use_featured_image'    => __('Use as featured image', 'karthi-portfolio'),
        'insert_into_item'      => __('Insert into project', 'karthi-portfolio'),
        'uploaded_to_this_item' => __('Uploaded to this project', 'karthi-portfolio'),
        'items_list'            => __('Projects list', 'karthi-portfolio'),
        'items_list_navigation' => __('Projects list navigation', 'karthi-portfolio'),
        'filter_items_list'     => __('Filter projects list', 'karthi-portfolio'),
    );

    $args = array(
        'label'               => __('Project', 'karthi-portfolio'),
        'labels'              => $labels,
        'supports'            => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-portfolio',
        'show_in_admin_bar'   => true,
        'show_in_nav_menus'   => true,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
        'rewrite'             => array('slug' => 'projects'),
    );

    register_post_type('project', $args);
}
add_action('init', 'karthi_portfolio_register_projects_cpt');

/**
 * Register Custom Post Type for Blog Posts
 */
function karthi_portfolio_register_blog_cpt() {
    $labels = array(
        'name'                  => _x('Blog Posts', 'Post Type General Name', 'karthi-portfolio'),
        'singular_name'         => _x('Blog Post', 'Post Type Singular Name', 'karthi-portfolio'),
        'menu_name'             => __('Blog', 'karthi-portfolio'),
        'name_admin_bar'        => __('Blog Post', 'karthi-portfolio'),
        'archives'              => __('Blog Archives', 'karthi-portfolio'),
        'attributes'            => __('Blog Attributes', 'karthi-portfolio'),
        'parent_item_colon'     => __('Parent Post:', 'karthi-portfolio'),
        'all_items'             => __('All Posts', 'karthi-portfolio'),
        'add_new_item'          => __('Add New Post', 'karthi-portfolio'),
        'add_new'               => __('Add New', 'karthi-portfolio'),
        'new_item'              => __('New Post', 'karthi-portfolio'),
        'edit_item'             => __('Edit Post', 'karthi-portfolio'),
        'update_item'           => __('Update Post', 'karthi-portfolio'),
        'view_item'             => __('View Post', 'karthi-portfolio'),
        'view_items'            => __('View Posts', 'karthi-portfolio'),
        'search_items'          => __('Search Post', 'karthi-portfolio'),
        'not_found'             => __('Not found', 'karthi-portfolio'),
        'not_found_in_trash'    => __('Not found in Trash', 'karthi-portfolio'),
    );

    $args = array(
        'label'               => __('Blog Post', 'karthi-portfolio'),
        'labels'              => $labels,
        'supports'            => array('title', 'editor', 'thumbnail', 'excerpt', 'author', 'comments'),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_position'       => 6,
        'menu_icon'           => 'dashicons-welcome-learn-new',
        'show_in_admin_bar'   => true,
        'show_in_nav_menus'   => true,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
        'rewrite'             => array('slug' => 'blog'),
    );

    register_post_type('blog_post', $args);
}
add_action('init', 'karthi_portfolio_register_blog_cpt');

/**
 * Add custom meta boxes for projects
 */
function karthi_portfolio_add_project_meta_boxes() {
    add_meta_box(
        'project_details',
        __('Project Details', 'karthi-portfolio'),
        'karthi_portfolio_project_details_callback',
        'project',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'karthi_portfolio_add_project_meta_boxes');

/**
 * Project details meta box callback
 */
function karthi_portfolio_project_details_callback($post) {
    wp_nonce_field('karthi_portfolio_save_project_meta', 'karthi_portfolio_project_nonce');

    $project_url = get_post_meta($post->ID, '_project_url', true);
    $github_url = get_post_meta($post->ID, '_github_url', true);
    $demo_url = get_post_meta($post->ID, '_demo_url', true);
    $project_tags = get_post_meta($post->ID, '_project_tags', true);

    ?>
    <p>
        <label for="project_url"><strong><?php _e('Project URL:', 'karthi-portfolio'); ?></strong></label><br>
        <input type="url" id="project_url" name="project_url" value="<?php echo esc_attr($project_url); ?>" style="width: 100%; max-width: 500px; margin-top: 5px;">
    </p>
    <p>
        <label for="github_url"><strong><?php _e('GitHub URL:', 'karthi-portfolio'); ?></strong></label><br>
        <input type="url" id="github_url" name="github_url" value="<?php echo esc_attr($github_url); ?>" style="width: 100%; max-width: 500px; margin-top: 5px;">
    </p>
    <p>
        <label for="demo_url"><strong><?php _e('Demo URL:', 'karthi-portfolio'); ?></strong></label><br>
        <input type="url" id="demo_url" name="demo_url" value="<?php echo esc_attr($demo_url); ?>" style="width: 100%; max-width: 500px; margin-top: 5px;">
    </p>
    <p>
        <label for="project_tags"><strong><?php _e('Tags (comma-separated):', 'karthi-portfolio'); ?></strong></label><br>
        <input type="text" id="project_tags" name="project_tags" value="<?php echo esc_attr($project_tags); ?>" style="width: 100%; max-width: 500px; margin-top: 5px;">
    </p>
    <?php
}

/**
 * Save project meta box data
 */
function karthi_portfolio_save_project_meta($post_id) {
    // Check if nonce is valid
    if (!isset($_POST['karthi_portfolio_project_nonce']) || 
        !wp_verify_nonce($_POST['karthi_portfolio_project_nonce'], 'karthi_portfolio_save_project_meta')) {
        return;
    }

    // Check if autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check user permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Save project URL
    if (isset($_POST['project_url'])) {
        update_post_meta($post_id, '_project_url', sanitize_url($_POST['project_url']));
    }

    // Save GitHub URL
    if (isset($_POST['github_url'])) {
        update_post_meta($post_id, '_github_url', sanitize_url($_POST['github_url']));
    }

    // Save demo URL
    if (isset($_POST['demo_url'])) {
        update_post_meta($post_id, '_demo_url', sanitize_url($_POST['demo_url']));
    }

    // Save project tags
    if (isset($_POST['project_tags'])) {
        update_post_meta($post_id, '_project_tags', sanitize_text_field($_POST['project_tags']));
    }
}
add_action('save_post_project', 'karthi_portfolio_save_project_meta');

/**
 * Add theme options page
 */
function karthi_portfolio_add_theme_options() {
    add_theme_page(
        __('Theme Options', 'karthi-portfolio'),
        __('Theme Options', 'karthi-portfolio'),
        'edit_theme_options',
        'karthi-theme-options',
        'karthi_portfolio_theme_options_page'
    );
}
add_action('admin_menu', 'karthi_portfolio_add_theme_options');

/**
 * Theme options page callback
 */
function karthi_portfolio_theme_options_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Karthi Portfolio Theme Options', 'karthi-portfolio'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('karthi_portfolio_options');
            do_settings_sections('karthi-portfolio-options');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

/**
 * Register theme options
 */
function karthi_portfolio_register_options() {
    register_setting('karthi_portfolio_options', 'karthi_github_url');
    register_setting('karthi_portfolio_options', 'karthi_linkedin_url');
    register_setting('karthi_portfolio_options', 'karthi_twitter_url');
    register_setting('karthi_portfolio_options', 'karthi_email');

    add_settings_section(
        'karthi_social_links',
        __('Social Links', 'karthi-portfolio'),
        'karthi_portfolio_social_section_callback',
        'karthi-portfolio-options'
    );

    add_settings_field(
        'karthi_github_url',
        __('GitHub URL:', 'karthi-portfolio'),
        'karthi_portfolio_github_field',
        'karthi-portfolio-options',
        'karthi_social_links'
    );

    add_settings_field(
        'karthi_linkedin_url',
        __('LinkedIn URL:', 'karthi-portfolio'),
        'karthi_portfolio_linkedin_field',
        'karthi-portfolio-options',
        'karthi_social_links'
    );

    add_settings_field(
        'karthi_twitter_url',
        __('Twitter URL:', 'karthi-portfolio'),
        'karthi_portfolio_twitter_field',
        'karthi-portfolio-options',
        'karthi_social_links'
    );

    add_settings_field(
        'karthi_email',
        __('Email Address:', 'karthi-portfolio'),
        'karthi_portfolio_email_field',
        'karthi-portfolio-options',
        'karthi_social_links'
    );
}
add_action('admin_init', 'karthi_portfolio_register_options');

function karthi_portfolio_social_section_callback() {
    _e('Enter your social media links below:', 'karthi-portfolio');
}

function karthi_portfolio_github_field() {
    $value = get_option('karthi_github_url', 'https://github.com/KarthigeyanN');
    echo "<input type='url' name='karthi_github_url' value='" . esc_attr($value) . "' style='width: 400px;'>";
}

function karthi_portfolio_linkedin_field() {
    $value = get_option('karthi_linkedin_url', 'https://linkedin.com/in/kaarthi');
    echo "<input type='url' name='karthi_linkedin_url' value='" . esc_attr($value) . "' style='width: 400px;'>";
}

function karthi_portfolio_twitter_field() {
    $value = get_option('karthi_twitter_url', 'https://twitter.com/kaarthi');
    echo "<input type='url' name='karthi_twitter_url' value='" . esc_attr($value) . "' style='width: 400px;'>";
}

function karthi_portfolio_email_field() {
    $value = get_option('karthi_email', 'karthi02@gmail.com');
    echo "<input type='email' name='karthi_email' value='" . esc_attr($value) . "' style='width: 400px;'>";
}

/**
 * Customize excerpt length
 */
function karthi_portfolio_excerpt_length($length) {
    return 30;
}
add_filter('excerpt_length', 'karthi_portfolio_excerpt_length');

/**
 * Customize excerpt more text
 */
function karthi_portfolio_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'karthi_portfolio_excerpt_more');

/**
 * Add custom body classes
 */
function karthi_portfolio_body_classes($classes) {
    if (is_front_page()) {
        $classes[] = 'home-page';
    }
    return $classes;
}
add_filter('body_class', 'karthi_portfolio_body_classes');

/**
 * Fallback menu function
 */
function karthi_portfolio_default_menu() {
    echo '<ul class="nav-menu">';
    echo '<li><a href="' . home_url() . '">Home</a></li>';
    echo '<li><a href="' . get_post_type_archive_link('project') . '">Projects</a></li>';
    echo '<li><a href="' . get_post_type_archive_link('blog_post') . '">Blog</a></li>';
    echo '<li><a href="' . get_permalink(get_page_by_path('about')) . '">About</a></li>';
    echo '<li><a href="' . get_permalink(get_page_by_path('contact')) . '">Contact</a></li>';
    echo '</ul>';
}

/**
 * Theme customizer settings
 */
function karthi_portfolio_customize_register($wp_customize) {
    // Add section for theme options
    $wp_customize->add_section('karthi_portfolio_theme_section', array(
        'title'    => __('Theme Options', 'karthi-portfolio'),
        'priority' => 30,
    ));

    // Add setting for default theme
    $wp_customize->add_setting('karthi_default_theme', array(
        'default'           => 'light',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_control('karthi_default_theme', array(
        'label'   => __('Default Theme Mode', 'karthi-portfolio'),
        'section' => 'karthi_portfolio_theme_section',
        'type'    => 'radio',
        'choices' => array(
            'light' => __('Light', 'karthi-portfolio'),
            'dark'  => __('Dark', 'karthi-portfolio'),
        ),
    ));
}
add_action('customize_register', 'karthi_portfolio_customize_register');

/**
 * Output default theme to page
 */
function karthi_portfolio_output_default_theme() {
    $default_theme = get_theme_mod('karthi_default_theme', 'light');
    echo '<script>document.documentElement.setAttribute("data-theme", "' . esc_js($default_theme) . '");</script>';
}
add_action('wp_head', 'karthi_portfolio_output_default_theme');