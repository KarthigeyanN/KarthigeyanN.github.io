# Quick Installation Guide

## For WordPress.com (Managed WordPress)

1. **Zip the theme folder:**
   - Right-click the `karthi-theme` folder
   - Select "Send to" → "Compressed (zipped) folder"
   - Name it `karthi-theme.zip`

2. **Upload to WordPress.com:**
   - Log in to your WordPress.com dashboard
   - Go to **Themes → Upload**
   - Upload the `karthi-theme.zip` file
   - Activate the theme

3. **Follow the setup guide:**
   - See `SETUP_GUIDE.md` for detailed configuration steps

## For Self-Hosted WordPress

### Option 1: Direct Upload (Easiest)

1. **Zip the theme:**
   - Compress the `karthi-theme` folder into `karthi-theme.zip`

2. **Upload via WordPress Admin:**
   - Go to **Appearance → Themes → Add New → Upload Theme**
   - Choose `karthi-theme.zip`
   - Click **Install Now**
   - Click **Activate**

### Option 2: FTP Upload

1. **Extract the theme folder**

2. **Upload via FTP:**
   - Connect to your server
   - Navigate to `/wp-content/themes/`
   - Upload the `karthi-theme` folder
   - Go to **Appearance → Themes** in WordPress
   - Activate "Karthi Portfolio"

## After Installation

1. **Configure social links:**
   - Go to **Appearance → Theme Options**
   - Enter your GitHub, LinkedIn, Twitter, and email

2. **Create pages:**
   - Create "About" page (slug: `about`)
   - Create "Contact" page (slug: `contact`)

3. **Set up menu:**
   - Go to **Appearance → Menus**
   - Create "Primary Menu" with links to Home, Projects, Blog, About, Contact
   - Assign to "Primary Menu" location

4. **Add content:**
   - Add projects via **Projects → Add New**
   - Add blog posts via **Blog → Add New**

## Need Help?

See `SETUP_GUIDE.md` for detailed step-by-step instructions.