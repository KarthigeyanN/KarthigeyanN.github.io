# WordPress Setup Guide - Karthi Portfolio Theme

This guide will walk you through setting up the Karthi Portfolio theme on your WordPress site.

## Prerequisites

- WordPress 5.0 or higher installed
- FTP access or file manager access to your WordPress installation
- Admin access to your WordPress dashboard

## Step-by-Step Setup

### 1. Upload the Theme

#### Option A: Via WordPress Admin (Recommended)

1. **Zip the theme folder:**
   - Navigate to the `karthi-theme` folder
   - Select all files and create a zip archive named `karthi-theme.zip`
   - Make sure the zip contains the theme files directly (not in a subfolder)

2. **Upload to WordPress:**
   - Log in to your WordPress admin dashboard
   - Go to **Appearance → Themes**
   - Click **Add New** → **Upload Theme**
   - Click **Choose File** and select `karthi-theme.zip`
   - Click **Install Now**
   - Once installed, click **Activate**

#### Option B: Via FTP

1. **Extract the theme:**
   - Unzip `karthi-theme.zip` on your computer

2. **Upload via FTP:**
   - Connect to your server using FTP client (FileZilla, Cyberduck, etc.)
   - Navigate to `/wp-content/themes/`
   - Upload the entire `karthi-theme` folder
   - Wait for upload to complete

3. **Activate the theme:**
   - Go to **Appearance → Themes** in WordPress admin
   - Find "Karthi Portfolio" and click **Activate**

### 2. Configure Theme Options

1. **Access Theme Options:**
   - Go to **Appearance → Theme Options**
   - You'll see fields for social media links

2. **Enter Your Social Links:**
   - **GitHub URL:** `https://github.com/KarthigeyanN` (or your GitHub profile)
   - **LinkedIn URL:** `https://linkedin.com/in/kaarthi` (or your LinkedIn profile)
   - **Twitter URL:** `https://twitter.com/kaarthi` (or your Twitter profile)
   - **Email Address:** `karthi02@gmail.com` (or your email)
   - Click **Save Changes**

### 3. Set Up Navigation Menu

1. **Create a Menu:**
   - Go to **Appearance → Menus**
   - Click **create a new menu**
   - Name it "Primary Menu"
   - Click **Create Menu**

2. **Add Menu Items:**
   
   **From Pages (if you've created them):**
   - Check the boxes next to your pages (Home, About, Contact, etc.)
   - Click **Add to Menu**
   
   **Or add Custom Links:**
   - Click **Custom Links** tab
   - Add these links:
     - URL: `/` | Link Text: `Home`
     - URL: `/projects` | Link Text: `Projects`
     - URL: `/blog` | Link Text: `Blog`
     - URL: `/about` | Link Text: `About` (if page exists)
     - URL: `/contact` | Link Text: `Contact` (if page exists)
   - Click **Add to Menu** for each

3. **Arrange Menu Items:**
   - Drag and drop to reorder items
   - Drag items slightly right to create submenus (if needed)

4. **Assign Menu Location:**
   - Check the box next to **Primary Menu** under "Menu Settings"
   - Click **Save Menu**

### 4. Create Required Pages

#### About Page

1. Go to **Pages → Add New**
2. Title: `About`
3. URL slug should be: `about` (WordPress will create this automatically)
4. Add your content in the editor:
   ```
   <p>I'm Karthi — an engineer, developer, and scientific thinker based in the United States. I build software that sits at the intersection of elegant engineering and rigorous scientific thinking.</p>
   
   <p>With a deep passion for clean architecture, machine learning, and open-source development, I strive to create solutions that are not only functional but beautiful in their design. I believe the best software emerges when we apply the scientific method to engineering challenges.</p>
   
   <p>When I'm not coding, you'll find me exploring new technologies, contributing to open-source projects, or diving into research papers on AI and systems design.</p>
   ```
5. Click **Publish**

#### Contact Page

1. Go to **Pages → Add New**
2. Title: `Contact`
3. URL slug should be: `contact`
4. Add your contact information or install a contact form plugin like Contact Form 7 or WPForms
5. Click **Publish**

### 5. Configure Homepage Settings

1. Go to **Settings → Reading**
2. Under "Your homepage displays":
   - Select **A static page**
   - For "Homepage", select a page you want to use (or create a new "Home" page)
   - For "Posts page", you can leave it as "-- Select --" or create a "Blog" page
3. Click **Save Changes**

**Note:** The theme's `front-page.php` will automatically display the hero section and featured projects on your homepage.

### 6. Add Your First Project

1. Go to **Projects → Add New**
2. Fill in the project details:
   - **Title:** Portfolio Website
   - **Content:** 
     ```
     Personal portfolio built with WordPress, featuring dark/light theme, particle animations, and responsive design.
     ```
   - **Excerpt:** (optional short description)
   - **Featured Image:** Upload a project screenshot or logo
   
3. In the "Project Details" meta box:
   - **Project URL:** `https://karthigeyann.github.io`
   - **GitHub URL:** `https://github.com/KarthigeyanN/PersonalWebsite`
   - **Demo URL:** (leave empty or add live demo link)
   - **Tags:** `WordPress, Portfolio, JavaScript`
   
4. Click **Publish**

### 7. Add Your First Blog Post

1. Go to **Blog → Add New**
2. Write your post using the WordPress editor
3. Add a title and content
4. Optionally add a featured image
5. Set categories and tags
6. Click **Publish**

### 8. Configure Additional Settings (Optional)

#### Permalinks (Recommended)

1. Go to **Settings → Permalinks**
2. Select "Post name" or "Custom Structure"
3. Click **Save Changes**

This will make your URLs cleaner (e.g., `/projects/my-project` instead of `/?p=123`).

#### Customize Theme Colors

To customize colors, you'll need to edit the `style.css` file:

1. Go to **Appearance → Theme Editor**
2. Select `style.css` from the right sidebar
3. Find the CSS variables section (around line 400+):
   ```css
   :root {
     --accent: #0077ff;           /* Change this to your preferred color */
     --accent-secondary: #7c3aed;
     /* ... other variables */
   }
   ```
4. Modify the colors to match your brand
5. Click **Update File**

**Note:** For production sites, it's better to use a child theme or custom CSS plugin rather than editing the theme directly.

## Content Migration from Jekyll

If you have existing content from your Jekyll site:

### Blog Posts

1. Go through your `blog/_posts/` folder
2. For each post:
   - Copy the title and content
   - Create a new post in WordPress (**Blog → Add New**)
   - Paste the content
   - Set the publication date to match the original
   - Publish

### About Page Content

Your About page content is already included in the theme as fallback content, but you can:
1. Edit the About page in WordPress
2. Replace with your custom content

### Projects

1. Go through your `_data/featured.yml` and `projects/` folder
2. Create each project in WordPress (**Projects → Add New**)
3. Fill in all the details from your Jekyll files

## Testing Your Site

1. **View your homepage** - Should show hero section with your name and tagline
2. **Test navigation** - Click through all menu items
3. **Test theme toggle** - Click the sun/moon icon to switch between light and dark modes
4. **Check responsiveness** - Resize browser or view on mobile device
5. **Test projects page** - Go to `/projects` to see your project listings
6. **Test blog** - Go to `/blog` to see blog posts
7. **Verify social links** - Check footer social icons link to correct profiles

## Troubleshooting

### Menu Not Showing

- Make sure you've assigned a menu to the "Primary Menu" location
- Go to **Appearance → Menus** and verify the menu assignment

### Projects Not Appearing on Homepage

- Make sure you've published at least 3 projects
- The homepage displays the 3 most recent projects
- If no projects exist, it shows fallback content

### Theme Toggle Not Working

- Make sure `theme.js` is loaded (check browser console for errors)
- Verify the file path in `functions.php` is correct

### Styles Not Loading

- Go to **Settings → Permalinks** and click **Save Changes** (flushes rewrite rules)
- Clear any caching plugins
- Check browser console for 404 errors on CSS files

## Next Steps

1. **Install Recommended Plugins:**
   - Contact Form 7 or WPForms (for contact form)
   - Yoast SEO (for SEO optimization)
   - WP Super Cache or W3 Total Cache (for performance)

2. **Customize Further:**
   - Add a custom logo via **Appearance → Customize → Site Identity**
   - Modify colors in `style.css`
   - Add more sections as needed

3. **Optimize Performance:**
   - Enable caching
   - Optimize images before uploading
   - Consider using a CDN

4. **Launch:**
   - Review all pages and content
   - Test on multiple devices and browsers
   - Set up analytics (Google Analytics, etc.)
   - Go live!

## Support

If you encounter any issues:
1. Check the theme documentation in `README.md`
2. Verify all setup steps were completed
3. Check WordPress debug log for errors
4. Visit the [GitHub repository](https://github.com/KarthigeyanN/PersonalWebsite) for updates

## Congratulations! 🎉

Your WordPress portfolio site is now ready! You can start adding content and customizing the theme to match your brand.