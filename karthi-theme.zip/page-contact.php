<?php get_header(); ?>

<main>
  <div class="page-content">
    <h1>Contact</h1>

    <?php
    // Try to get the Contact page content
    $contact_page = get_page_by_path('contact');
    if ($contact_page) {
      echo apply_filters('the_content', $contact_page->post_content);
    } else {
      // Fallback content
    ?>
      <p>Feel free to reach out to me through any of these channels:</p>

      <div class="contact-form">
        <div class="form-group">
          <label for="name">Name</label>
          <input type="text" id="name" name="name" placeholder="Your name">
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" placeholder="your@email.com">
        </div>
        <div class="form-group">
          <label for="message">Message</label>
          <textarea id="message" name="message" placeholder="Your message..."></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Send Message</button>
      </div>
    <?php } ?>
  </div>
</main>

<?php get_footer(); ?>