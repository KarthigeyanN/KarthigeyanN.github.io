<?php get_header(); ?>

<main>
  <?php while (have_posts()) : the_post(); ?>
    <article class="post">
      <h1><?php the_title(); ?></h1>
      <div class="meta">
        <span><?php echo get_the_date(); ?></span>
        <?php if (get_the_author()) : ?>
          <span>&bull;</span>
          <span><?php the_author(); ?></span>
        <?php endif; ?>
      </div>
      <div class="content">
        <?php the_content(); ?>
      </div>
    </article>
  <?php endwhile; ?>
</main>

<?php get_footer(); ?>