<?php get_header(); ?>

<main>
  <?php while (have_posts()) : the_post(); ?>
    <article class="project-page">
      <h1><?php the_title(); ?></h1>
      <?php if (get_the_excerpt()) : ?>
        <p><?php the_excerpt(); ?></p>
      <?php endif; ?>

      <div class="content">
        <?php the_content(); ?>
      </div>

      <?php
      // Get project meta data
      $project_url = get_post_meta(get_the_ID(), '_project_url', true);
      $github_url = get_post_meta(get_the_ID(), '_github_url', true);
      $demo_url = get_post_meta(get_the_ID(), '_demo_url', true);
      $project_tags = get_post_meta(get_the_ID(), '_project_tags', true);
      ?>

      <?php if ($project_url || $github_url || $demo_url) : ?>
        <div class="card-links" style="margin-top: 2rem;">
          <?php if ($demo_url) : ?>
            <a href="<?php echo esc_url($demo_url); ?>" class="btn btn-sm">Live Demo &rarr;</a>
          <?php endif; ?>
          <?php if ($github_url) : ?>
            <a href="<?php echo esc_url($github_url); ?>" class="btn btn-sm btn-outline">Source Code</a>
          <?php endif; ?>
          <?php if ($project_url) : ?>
            <a href="<?php echo esc_url($project_url); ?>" class="btn btn-sm">Project Page &rarr;</a>
          <?php endif; ?>
        </div>
      <?php endif; ?>

      <?php if ($project_tags) : ?>
        <div class="card-tags" style="margin-top: 1.5rem;">
          <?php
          $tags = explode(',', $project_tags);
          foreach ($tags as $tag) {
            $tag = trim($tag);
            if ($tag) {
              echo '<span class="tag">' . esc_html($tag) . '</span>';
            }
          }
          ?>
        </div>
      <?php endif; ?>
    </article>
  <?php endwhile; ?>
</main>

<?php get_footer(); ?>