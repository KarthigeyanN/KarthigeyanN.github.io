<?php get_header(); ?>

<main>
  <?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
      <article class="post">
        <h1><?php the_title(); ?></h1>
        <div class="content">
          <?php the_content(); ?>
        </div>
      </article>
    <?php endwhile; ?>
  <?php else : ?>
    <div class="page-content">
      <h1>Welcome</h1>
      <p>No content found.</p>
    </div>
  <?php endif; ?>
</main>

<?php get_footer(); ?>