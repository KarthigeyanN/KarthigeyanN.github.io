# Karthi Portfolio WordPress Theme

A modern, responsive portfolio theme for WordPress with dark/light mode, particle animations, and clean design. Built for engineers, developers, and scientific thinkers.

## Features

- **Dark/Light Mode Toggle** - Automatic theme switching with localStorage persistence
- **Particle Animations** - Interactive particle background with connection lines
- **Responsive Design** - Mobile-first approach with breakpoints at 768px and 480px
- **Custom Post Types** - Projects and Blog Posts with custom meta fields
- **Modern UI** - Gradient accents, smooth animations, and hover effects
- **Grid Background** - Subtle scientific grid pattern
- **Social Integration** - Configurable social media links
- **SEO Friendly** - Clean markup with proper heading hierarchy

## Installation

### Method 1: Upload via WordPress Admin

1. Download or clone this theme
2. Zip the `karthi-theme` folder (the folder should contain `style.css`, `functions.php`, etc.)
3. Go to WordPress Admin → Appearance → Themes → Add New → Upload Theme
4. Upload the zip file and activate the theme

### Method 2: FTP Upload

1. Connect to your server via FTP
2. Navigate to `/wp-content/themes/`
3. Upload the entire `karthi-theme` folder
4. Go to WordPress Admin → Appearance → Themes
5. Activate the "Karthi Portfolio" theme

## Setup Instructions

### 1. Configure Theme Options

After activation, go to **Appearance → Theme Options** to set up:
- GitHub URL
- LinkedIn URL
- Twitter URL
- Email address

### 2. Set Up Navigation Menu

1. Go to **Appearance → Menus**
2. Create a new menu named "Primary Menu"
3. Add the following custom links:
   - Home (link to your homepage)
   - Projects (link to `/projects`)
   - Blog (link to `/blog`)
   - About (link to your About page)
   - Contact (link to your Contact page)
4. Assign the menu to "Primary Menu" location
5. Save the menu

### 3. Create Required Pages

Create the following pages in WordPress:

#### About Page
- Title: "About"
- Slug: `about`
- Content: Add your bio, skills, and experience
- Publish the page

#### Contact Page
- Title: "Contact"
- Slug: `contact`
- Content: Add your contact information or use a contact form plugin
- Publish the page

### 4. Set Homepage

1. Go to **Settings → Reading**
2. Select "A static page" for "Your homepage displays"
3. Choose a page to use as your homepage (or create a new one)
4. Save changes

### 5. Add Projects

1. Go to **Projects → Add New**
2. Fill in:
   - Title: Project name
   - Content: Project description
   - Excerpt: Short description (appears on cards)
   - Featured Image: Project screenshot/logo
3. In the "Project Details" meta box:
   - Project URL: Link to project page
   - GitHub URL: Link to repository
   - Demo URL: Link to live demo
   - Tags: Comma-separated tags (e.g., "Python, Machine Learning, React")
4. Publish the project

### 6. Add Blog Posts

1. Go to **Blog → Add New**
2. Write your post using the WordPress editor
3. Add a featured image (optional)
4. Set categories and tags
5. Publish the post

## Theme Structure

```
karthi-theme/
├── style.css          - Main stylesheet with all CSS
├── functions.php      - Theme functions and custom post types
├── header.php         - Header template with navigation
├── footer.php         - Footer template with social links
├── front-page.php     - Homepage template with hero and featured projects
├── index.php          - Default template
├── page-about.php     - About page template
├── page-contact.php   - Contact page template
├── single.php         - Single post template
├── single-project.php - Single project template
├── archive.php        - Archive template for blog and projects
└── js/
    ├── theme.js       - Dark/light mode toggle functionality
    └── particles.js   - Particle animation script
```

## Customization

### Colors

The theme uses CSS custom properties (variables) for easy color customization. Edit the following in `style.css`:

```css
:root {
  --accent: #0077ff;           /* Primary accent color */
  --accent-secondary: #7c3aed; /* Secondary accent color */
  --bg: #ffffff;               /* Background color */
  --text: #111111;             /* Text color */
  /* ... and more */
}
```

### Fonts

The theme uses Google Fonts (Inter). To change the font:
1. Edit the Google Fonts URL in `functions.php` (line 27)
2. Update the font-family in `style.css` (line 14)

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- IE 11 (partial support)

## Credits

- Original design: [Karthigeyan N](https://karthigeyann.github.io)
- Fonts: [Inter](https://fonts.google.com/specimen/Inter) by Rasmus Andersson
- Icons: SVG icons from various sources

## License

MIT License - feel free to use this theme for personal or commercial projects.

## Support

For issues or questions, please visit the [GitHub repository](https://github.com/KarthigeyanN/PersonalWebsite).