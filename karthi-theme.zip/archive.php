<?php get_header(); ?>

<main>
  <div class="blog-list">
    <h1>
      <?php if (is_post_type_archive('project')) : ?>
        Projects
      <?php elseif (is_post_type_archive('blog_post')) : ?>
        Blog
      <?php elseif (is_category()) : ?>
        Category: <?php single_cat_title(); ?>
      <?php elseif (is_tag()) : ?>
        Tag: <?php single_tag_title(); ?>
      <?php else : ?>
        Archive
      <?php endif; ?>
    </h1>

    <?php if (have_posts()) : ?>
      <ul>
        <?php while (have_posts()) : the_post(); ?>
          <li>
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            <span><?php echo get_the_date(); ?></span>
            <?php if (get_the_excerpt()) : ?>
              <p><?php echo wp_trim_words(get_the_excerpt(), 30); ?></p>
            <?php endif; ?>
          </li>
        <?php endwhile; ?>
      </ul>

      <?php
      // Pagination
      the_posts_pagination(array(
        'prev_text' => '&larr; Previous',
        'next_text' => 'Next &rarr;',
      ));
      ?>
    <?php else : ?>
      <p>No posts found.</p>
    <?php endif; ?>
  </div>
</main>

<?php get_footer(); ?>