<?php get_header(); ?>

<main>
  <!-- Hero Section -->
  <section class="hero">
    <h1>Karthi</h1>
    <p class="tagline">Engineer &bull; Developer &bull; Scientific Thinker</p>
    <p class="subtitle">Building elegant solutions at the intersection of software engineering and scientific thinking. Passionate about clean code, machine learning, and open source.</p>

    <div class="hero-buttons">
      <a href="<?php echo get_post_type_archive_link('project'); ?>" class="btn btn-primary">View Projects</a>
      <a href="<?php echo get_permalink(get_page_by_path('about')); ?>" class="btn">About Me</a>
      <a href="<?php echo get_post_type_archive_link('blog_post'); ?>" class="btn btn-outline">Read Blog</a>
    </div>
  </section>

  <!-- Featured Projects -->
  <section class="featured">
    <div class="section-header">
      <h2>Featured Projects</h2>
      <p>Some of my recent work and side projects</p>
    </div>

    <div class="grid">
      <?php
      // Query featured projects
      $featured_projects = new WP_Query(array(
        'post_type'      => 'project',
        'posts_per_page' => 3,
        'post_status'    => 'publish',
      ));

      if ($featured_projects->have_posts()) :
        while ($featured_projects->have_posts()) : $featured_projects->the_post();
          $project_url = get_post_meta(get_the_ID(), '_project_url', true);
          $github_url = get_post_meta(get_the_ID(), '_github_url', true);
          $demo_url = get_post_meta(get_the_ID(), '_demo_url', true);
      ?>
        <div class="card">
          <h3><?php the_title(); ?></h3>
          <p><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
          <div class="card-links">
            <?php if ($demo_url) : ?>
              <a href="<?php echo esc_url($demo_url); ?>" class="btn btn-sm">Live Demo &rarr;</a>
            <?php endif; ?>
            <?php if ($github_url) : ?>
              <a href="<?php echo esc_url($github_url); ?>" class="btn btn-sm btn-outline">Source Code</a>
            <?php endif; ?>
          </div>
        </div>
      <?php
        endwhile;
        wp_reset_postdata();
      else :
        // Fallback to static content if no projects
      ?>
        <div class="card">
          <h3>Portfolio Website</h3>
          <p>Personal portfolio built with WordPress, featuring dark/light theme, particle animations, and responsive design.</p>
          <div class="card-links">
<a href="https://karthigeyann.github.io" class="btn btn-sm">Live Demo &rarr;</a>
<a href="https://github.com/KarthigeyanN/PersonalWebsite" class="btn btn-sm btn-outline">Source Code</a>
          </div>
        </div>
        <div class="card">
          <h3>ML Model Explorer</h3>
          <p>Interactive visualization tool for exploring machine learning model performance metrics and training curves.</p>
          <div class="card-links">
            <a href="#" class="btn btn-sm">Live Demo &rarr;</a>
            <a href="#" class="btn btn-sm btn-outline">Source Code</a>
          </div>
        </div>
        <div class="card">
          <h3>CLI Productivity Toolkit</h3>
          <p>A collection of command-line utilities for developers, automating common workflows and improving productivity.</p>
          <div class="card-links">
            <a href="#" class="btn btn-sm">Live Demo &rarr;</a>
            <a href="#" class="btn btn-sm btn-outline">Source Code</a>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </section>
</main>

<?php get_footer(); ?>